// HW2 starter code for testing
#define CATCH_CONFIG_MAIN			// this line tells Catch to provide a main() function
#define CATCH_CONFIG_COLOUR_NONE	// this line avoids problems due to color-coding the output
#include "catch.hpp"
#include "Poly.h" 

TEST_CASE("Testing empty polyline", "[Poly]") 
{
	INFO("Hint: testing all methods with an empty polyline");

	Poly<int> p;

	REQUIRE(p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 0);

	REQUIRE(!p.insert(1, 2, -1));
	REQUIRE(!p.insert(1, 2, 1));
	REQUIRE(!p.remove(-1));
	REQUIRE(!p.remove(0));
	REQUIRE(!p.remove(1));
	REQUIRE(p.getCoordinateX(0) == -1);		
	REQUIRE(p.getCoordinateY(0) == -1);
	REQUIRE(p.getArcLength() == 0.0);
	REQUIRE(!p.translate(1, 2));

	INFO("Hint: testing several methods after clearing an empty polyline");
	p.clear();
	REQUIRE(p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 0);
	REQUIRE(!p.remove(0));

	
}

TEST_CASE("Testing polyline with a single node", "[Poly]") 
{
	INFO("Hint: testing all methods on a polyline with 1 node");

	Poly<int> p;
	
	REQUIRE(p.insert(1, 2, 0));

	REQUIRE(!p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 1);
	REQUIRE(p.getCoordinateX(0) == 1);
	REQUIRE(p.getCoordinateY(0) == 2);
	REQUIRE(p.getArcLength() == 0.0);
	REQUIRE(p.translate(3, 4));
	REQUIRE(p.getCoordinateX(0) == 4);
	REQUIRE(p.getCoordinateY(0) == 6);
	REQUIRE(p.getCoordinateX(-1) == -1);
	REQUIRE(p.getCoordinateY(-1) == -1);

	// TO-DO:  add more REQUIRE statements here to test a polyline with 1 node.

}


TEST_CASE("Testing the copy constructor", "[Poly]")
{
	INFO("Hint: testing the copy constructor");

	Poly<int> p;

	REQUIRE(p.insert(1, 2, 0));
	REQUIRE(p.insert(3, 4, 1));
	REQUIRE(p.insert(5, 6, 2));
	REQUIRE(p.insert(7, 8, 0));

	Poly<int>x(p); 

	REQUIRE(x.getArcLength() == p.getArcLength());
	REQUIRE(x.getCoordinateX(0) == p.getCoordinateX(0));
	REQUIRE(x.getCoordinateY(0) == p.getCoordinateY(0));
	REQUIRE(x.getNumberOfPoints() == p.getNumberOfPoints());
	REQUIRE(!x.isEmpty());
}

TEST_CASE("Testing the overloaded assignment operator", "[Poly]")
{
	INFO("Hint: testing the overloaded assignment operator");

	Poly<int> p;

	REQUIRE(p.insert(1, 2, 0));
	REQUIRE(p.insert(3, 4, 1));
	REQUIRE(p.insert(5, 6, 2));
	REQUIRE(p.insert(7, 8, 0));

	Poly<int> x;

	x.operator=(p);

	REQUIRE(x.getCoordinateX(0) == p.getCoordinateX(0));
}

TEST_CASE("Testing the overloaded plus operator", "[Poly]")
{
	INFO("Hint: testing the overloaded plus operator");

	Poly<int> p;

	REQUIRE(p.insert(1, 2, 0));
	REQUIRE(p.insert(3, 4, 1));
	REQUIRE(p.insert(5, 6, 2));
	REQUIRE(p.insert(7, 8, 0));

	Poly<int> x;
	x.operator=(p);


	//x.operator+(p);

	//REQUIRE(x.getCoordinateX(4) == p.getCoordinateX(0));
}

TEST_CASE("Testing the insert method", "[Poly]")
{
	INFO("Hint: testing the insert method");

	Poly<int> p;

	REQUIRE(p.insert(1, 2, 0));
	REQUIRE(p.insert(3, 4, 1));
	REQUIRE(p.insert(5, 6, 2));
	REQUIRE(p.insert(7, 8, 0));
	REQUIRE(p.insert(9, 10, 1));

	
}