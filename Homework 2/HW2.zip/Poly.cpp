/////////////////////////////////////////////////////////////
//  HW2 -- starter - ALA 2/2018

/** Implementation file for the class Poly.
 @file Poly.cpp */

#include "Poly.h"
#include "Node.h"
#include <cstddef>
#include <iostream>

using namespace std;

// TO-DO: Implement the default constructor here.
template<class ItemType>
Poly<ItemType>::Poly() : headPtr(nullptr), pointCount(0)
{
}  // end default constructor

// TO-DO: Implement the copy constructor here.
template<class ItemType>
Poly<ItemType>::Poly(const Poly<ItemType>& aPoly)
{
	pointCount = aPoly.pointCount;
	Node<ItemType> *origChainPtr = aPoly.headPtr;
	
	if (origChainPtr == nullptr)
	{
		headPtr = nullptr;
	}

	else
	{
		headPtr = new Node<ItemType>();

		headPtr->setX(origChainPtr->getX());
		headPtr->setY(origChainPtr->getY());

		origChainPtr = origChainPtr->getNext();

		Node<ItemType> *newChainPtr = headPtr;
		while (origChainPtr != nullptr)
		{
		
			Node<ItemType> *newNodePtr = new Node<ItemType>(origChainPtr->getX(), origChainPtr->getY());

			newChainPtr->setNext(newNodePtr);
			newChainPtr = newChainPtr->getNext();

			origChainPtr = origChainPtr->getNext();
		}
		newChainPtr->setNext(nullptr);
	}
	
} // end copy constructor

// TO-DO: Implement the isEmpty method here.
template<class ItemType>
bool Poly<ItemType>::isEmpty() const
{

	return (pointCount == 0);
	
}  // end isEmpty

// TO-DO: Implement the getNumberOfPoints method here.
template<class ItemType>
int Poly<ItemType>::getNumberOfPoints() const
{
	return pointCount;
}  // end getNumberOfPoints

// TO-DO: Implement the insert method here.  The method must
// insert a node at location 'index', as described in the HW specification.
// No nodes are deleted. If index == 0, then the new node becomes the head node.
// If index == pointCount, then the new node is appended to the tail of the linked list.
template<class ItemType>
bool Poly<ItemType>::insert(const ItemType x, const ItemType y, int index)
{


	if (index > pointCount || index < 0)
		return false;
	
	Node<ItemType> *node = new Node<ItemType>(x, y);

	if (index == 0 && pointCount != 0)
	{

		node->setNext(headPtr);
		headPtr = node;

	}

	else
	{
		Node<ItemType> *node2 = new Node<ItemType>();

		if (index == 0)
		{
			node2 = headPtr;
			headPtr = node;
			node->setNext(node2);
		}
		else
		{
			node2 = getPointerTo(index - 1);

			node->setNext(node2->getNext());
			node2->setNext(node);
		}
		
	}

	pointCount++;

	return true;
}  // end add

// TO-DO: Implement the remove method here. 
// The node at location 'index', as described in the HW specification, must be removed.
template<class ItemType>
bool Poly<ItemType>::remove(const int index)
{
	if (index < 0 || index > pointCount || isEmpty())
		return false;

	Node<ItemType> *temp = headPtr;

	if (index == 0 && pointCount != 0)
	{
		headPtr = headPtr->getNext();

		delete temp;
	}
	else
	{
		temp = getPointerTo(index - 1);

		Node<ItemType> *newPtr = temp;
		temp->setNext(newPtr->getNext());

		delete newPtr;
	}

	pointCount--;
	return true;

}  // end remove

// TO-DO: Implement the clear method here. 
template<class ItemType>
void Poly<ItemType>::clear()
{
	while (!isEmpty())
		remove(pointCount);

}  // end clear

// TO-DO: Implement the getCoordinateX method here.
// If index is not valid, return -1 (instead of raising an exception).
template<class ItemType>
ItemType Poly<ItemType>::getCoordinateX(const int index) const
{
	if (isEmpty() || index < 0 || index > pointCount)
		return -1;

	Node<ItemType> *temp = headPtr;

	
	for (int c = 0; c < index; c++)
	{
		temp = temp->getNext();
	}
		return temp->getX();


}

// TO-DO: Implement the getCoordinateY method here.
// If index is not valid, return -1 (instead of raising an exception).
template<class ItemType>
ItemType Poly<ItemType>::getCoordinateY(const int index) const
{
	if (isEmpty() || index < 0 || index > pointCount)
		return -1;

	Node<ItemType> *temp = headPtr;

	
	for (int c = 0; c < index; c++)
	{
		temp = temp->getNext();
	}
	return temp->getY();
}

// TO-DO: Implement the getArcLength method here.
template<class ItemType>
double Poly<ItemType>::getArcLength() const
{
	double sum = 0;
	double x, y;

	if (!isEmpty() && pointCount > 1)
	{
		for (int c = 0; c < pointCount; c++)
		{
			x = getCoordinateX(c - 1) - getCoordinateX(c);
			y = getCoordinateY(c - 1) - getCoordinateY(c);

			sum = sum + sqrt(pow((x), 2.0) + pow((y), 2.0));
		}
	}
	return sum;
}  // end getArcLength

// TO-DO: Implement the translate method here.
template<class ItemType>
bool Poly<ItemType>::translate(const ItemType deltaX, const ItemType deltaY)
{
	if(isEmpty())
		return false;

	for (auto temp = headPtr; temp != nullptr; temp = temp->getNext())
	{
		temp->setX(temp->getX() + deltaX);
		temp->setY(temp->getY() + deltaY);
	}
	
	return true;

}

// TO-DO: Implement the destructor here
template<class ItemType>
Poly<ItemType>::~Poly()
{
	clear();
}


////////////////////////////////////////////////////////////////////////////////////
// overloaded operators

// TO-DO: Implement the operator+ method here
template<class ItemType>
Poly<ItemType>& Poly<ItemType>::operator+(const Poly<ItemType>& rightHandSide) const
{

	static Poly<ItemType> result;
	
	int c = 0;

	cout << "1" << endl;

	for (int lc = 0; lc < getNumberOfPoints(); lc++)
	{
		result.insert(getCoordinateX(lc), getCoordinateY(lc), c);
		c++;

	}

	cout << "2" << endl;

	for (int lc = 0; lc < rightHandSide.pointCount; lc++)
	{
		result.insert(rightHandSide.getCoordinateX(lc), rightHandSide.getCoordinateX(lc), c);
		c++;
	}

	cout << "3" << endl;

	return result; // Okay to change this statement; it is just a placeholder
}

// TO-DO: Implement the operator= method here
template<class ItemType>
Poly<ItemType>& Poly<ItemType>::operator=(const Poly<ItemType>& rightHandSide) 
{
	
	if (this != &rightHandSide)
	{
		this->clear();

		for (int c = 0; c < rightHandSide.pointCount; c++)
		{
			insert(rightHandSide.getCoordinateX(c), rightHandSide.getCoordinateY(c), c);
		}
	}

	return *this;

}

////////////////////////////////////////////////////////////////////////////////////
// private methods

// TO-DO: Implement the getPointerTo method here
template<class ItemType>
Node<ItemType> *Poly<ItemType>::getPointerTo(const int index) const
{
   Node<ItemType> *curPtr = headPtr;

   for (int c = 0; c != index; c++)
   {
	   curPtr = curPtr->getNext();
   }

   return curPtr;
}  // end getPointerTo